import SwiftUI
import MapKit

//MARK: Stretch #1 - Part I
struct MapView: UIViewRepresentable {
    func makeUIView(context: Context) -> MKMapView {
        return MKMapView()
    }
    
    func updateUIView(_ uiView: MKMapView, context: Context) {
        // You can configure the map view here if needed
    }
}
