import SwiftUI

//MARK: MVP - Part I
struct MyCustomModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.title)
            .foregroundColor(.green)
            .padding()
            .background(Color.yellow)
            .cornerRadius(10)
    }
}
