import SwiftUI

//MARK: Stretch #3 - Part I

struct TrapezoidShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let topWidth = rect.width * 0.6
        let bottomWidth = rect.width
        let height = rect.height
        let topOffset = (rect.width - topWidth) / 2
        
        path.move(to: CGPoint(x: 0, y: 0))
        path.addLine(to: CGPoint(x: topOffset, y: height))
        path.addLine(to: CGPoint(x: topOffset + topWidth, y: height))
        path.addLine(to: CGPoint(x: bottomWidth, y: 0))
        path.closeSubpath()
        
        return path
    }
}
