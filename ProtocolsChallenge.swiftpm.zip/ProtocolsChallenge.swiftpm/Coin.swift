import SwiftUI

//MARK: Stretch #2 - Part I
struct Coin: Identifiable {
    var id = UUID() // Adopt Identifiable for unique identification
    var name: String
    var value: Double
}
